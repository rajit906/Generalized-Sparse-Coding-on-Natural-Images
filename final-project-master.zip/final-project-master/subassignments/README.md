# Subassignments

This folder contains the Markdown files with the instructions for the incremental assignments that you work on throughout the development of your final project. In your repo, this folder will contain your _submissions_ for these assignments.
