# Step 6 Assignment

In this assignment, you will peer-review **two** of the team repos. You assignments are listed below. *Please make sure you find **both** repos that you are listed for below.*

1. annaj98, jamiexie, ArnavJain4, adkwok, JordanBailey7, goldenbear123
2. dipikakhullar, eujaee, goldenbear123, ldldylan, HowardYan520, zhang-vivian
3. acruz101, JordanBailey7, mashapaley, dipikakhullar, hasanm133, kadrobak, adkowk
4. ldldylan, HowardYan520, kadrobak, acruz101, kailchen, eujaee, mashapaley
5. kailchen, hasanm133, zhang-vivian, annaj98, jamiexie, ArnavJain4

Details on assignment structure to come.
