# Output

This folder contains output from this project. The CSV and TSV files contained herein are the original data set, and are included here for the purpose of demonstrating how to export data.

If you have a graphics file that visualizes the data, save it here as a png for importing into your presentation
