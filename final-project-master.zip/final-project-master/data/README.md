# Data

This folder contains the data for reproducing the analysis in [Insurance Charges & Smoking Habits](https://github.com/chrispyles/jupyter/tree/master/content/notebooks/insurance). All of the files contain the same data, but in different formats (CSV, TSV, and pipe-separated).
